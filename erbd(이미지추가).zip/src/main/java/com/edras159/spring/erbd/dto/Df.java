package com.edras159.spring.erbd.dto;

import java.util.ArrayList;

public class Df {
	
	public ArrayList<Row> rows; 
	
}
