
package com.edras159.spring.erbd.dto;

import java.util.List;
public class DfCharacterInfo {

    public List<Row> rows;

}
