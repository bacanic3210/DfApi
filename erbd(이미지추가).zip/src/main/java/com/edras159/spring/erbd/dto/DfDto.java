package com.edras159.spring.erbd.dto;

import lombok.Data;

@Data
public class DfDto {
	private String server;
	public String characterName;
}