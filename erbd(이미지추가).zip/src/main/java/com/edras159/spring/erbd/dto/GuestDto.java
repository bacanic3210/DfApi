package com.edras159.spring.erbd.dto;

import lombok.Data;

@Data
public class GuestDto {
	private Long bno;
	private String btext;
}