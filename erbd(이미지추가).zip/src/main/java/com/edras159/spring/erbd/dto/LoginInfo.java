package com.edras159.spring.erbd.dto;
import lombok.Data;

@Data
public class LoginInfo {
	private String userId;
	private String pwd;
}
