package com.edras159.spring.erbd.dto;

import lombok.Data;

@Data
public class TestDto {
	private long no;
	private String str_data;
}

