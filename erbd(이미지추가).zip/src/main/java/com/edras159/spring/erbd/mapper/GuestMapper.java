package com.edras159.spring.erbd.mapper;

import java.util.ArrayList;

import com.edras159.spring.erbd.dto.GuestDto;
import com.edras159.spring.erbd.dto.LoginInfo;

public interface GuestMapper {
	public ArrayList<GuestDto> getList();
	public GuestDto read(long bno);
	public void del(long bno);
	public void write(GuestDto dto);
	public void modify(GuestDto dto);
	
	public String login(LoginInfo log);
	public void signup(LoginInfo log);
}
