package com.edras159.spring.erbd.controller;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.edras159.spring.erbd.dto.ApiData;
import com.edras159.spring.erbd.dto.Df;
import com.edras159.spring.erbd.dto.DfDto;
import com.edras159.spring.erbd.dto.LoginInfo;
import com.edras159.spring.erbd.dto.Row;
import com.edras159.spring.erbd.service.GuestService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/df/*") // 프로젝트 루트 경로 이하 /guest 상위폴더로 진입 시 여기로 진입하게 됨.
@AllArgsConstructor // 필드 값을 매개변수로 하는 생성자를 스프링이 알아서 만들어 줌. 그리고 그런 형태의 생성자를 추가하면 스프링이 알아서 객체관리
					// 해줌(@Auto.. 처럼)
@Controller
public class DfController {

//	위에 @AllArgsConstructor 이걸 쓰면
//	롬복라이브러리가 아래 코드를 자동으로 삽입해줌

	//
//	public GuestController(GuestService service){
//		this.service = service;
//	}

	private GuestService service;

	@RequestMapping("/fame")
	public String fame(DfDto df, Model model) {
		HashMap<String, String> dfServer = new HashMap<String, String>();
		dfServer.put("카인", "cain");
		dfServer.put("디레지에", "diregie");
		dfServer.put("시로코", "siroco");
		dfServer.put("프레이", "prey");
		dfServer.put("카시야스", "casillas");
		dfServer.put("힐더", "hilder");
		dfServer.put("안톤", "anton");
		dfServer.put("바칼", "bakal");
		String UrlCharacterName = "";
		try {
			UrlCharacterName = URLEncoder.encode(df.getCharacterName(), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		String serverForApi = dfServer.get(df.getServer());
		String Api_URL = String.format("https://api.neople.co.kr/df/servers/%s/characters?characterName=%s&apikey=%s",
				serverForApi, UrlCharacterName, ApiData.API_KEY);
		RestTemplate restTemplate = new RestTemplate();
		URI uri = null; // java.net.URI 임포트 하셈
		try {
			uri = new URI(Api_URL);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		
		String m = restTemplate.getForObject(uri, String.class);
		log.info(m);
		Df s = restTemplate.getForObject(uri, Df.class);
		
		model.addAttribute("row", s);
		return "/df/character";
	}

	@GetMapping("/search")
	public void signup() {
	}

}