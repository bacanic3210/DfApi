package com.edras159.spring.erbd.dto;

import java.util.HashMap;
import java.util.Map;

public class ApiData {
	public static String API_KEY = "eUeiUgbBIV1hJtnKY3fTmBOcBCu2AgpM";
	
	/*
	 * public static HashMap<String, String> dfServer = new HashMap<String,
	 * String>() {{ dfServer.put("카인","cain"); dfServer.put("디레지에","diregie");
	 * dfServer.put("시로코","siroco"); dfServer.put("프레이","prey");
	 * dfServer.put("카시야스","casillas"); dfServer.put("힐더","hilder");
	 * dfServer.put("안톤","anton"); dfServer.put("바칼","bakal"); }};
	 */
}