
package com.edras159.spring.erbd.dto;

public class Row {

    public String serverId;
    public String characterId;
    public String characterName;
    public Integer level;
    public String jobId;
    public String jobGrowId;
    public String jobName;
    public String jobGrowName;
    public Integer fame;

}
