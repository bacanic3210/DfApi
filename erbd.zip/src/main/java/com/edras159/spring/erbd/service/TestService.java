package com.edras159.spring.erbd.service;

public interface TestService {
	public String getOne();
	public String getTwo();
	
	public void updateVisitorCount();
	public void insertDoodle();
	public void delTest();
	
}
