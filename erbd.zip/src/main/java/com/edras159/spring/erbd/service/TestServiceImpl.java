package com.edras159.spring.erbd.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edras159.spring.erbd.mapper.TestMapper;
import com.edras159.spring.erbd.dto.TestDto;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class TestServiceImpl implements TestService{

	@Setter(onMethod_ = @Autowired)
	private TestMapper mapper;	
	
	@Override
	public String getOne() {
		log.info("test===========");
		TestDto tvo = mapper.getData1();
		String one = tvo.getStr_data();
		return one;
	}

	@Override
	public String getTwo() {
		log.info("test===========");
		TestDto tvo = mapper.getData2();
		String two = tvo.getStr_data();
		return two;
	}
	
	@Override
	public void updateVisitorCount() {
		log.info("서비스 테스트 - visitor counter");
		mapper.updateVisitorCount();
	}
	
	@Override
	public void insertDoodle() {
		log.info("서비스 테스트 - 낙서장");
		mapper.insertDoodle();
	}
	
	@Override
	public void delTest() {
		log.info("서비스 테스트 - 삭제테스트");
		mapper.delTest();
	}

}
